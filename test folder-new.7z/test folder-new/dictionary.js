 

var app = angular.module("myApp", []);
app.controller('tableCtrl', function ($scope){ 
 
         $scope.table =[
        {
            'name' : 'kljenj',
            'description' : 'kvbejiobneriovbrnvbier'
        },
        {
            'name' : 'njedogjer',
            'description': 'klnbbbolmoebenrobvrnme'
        },
        {
            'name' : 'nejvne',
            'description': 'lkvnmoblerkn'
        },
        ]; 

        $scope.addRow = function() {
            $scope.table.push({'name':$scope.name, 'description' : $scope.description});
            $scope.name = '';
            $scope.description = '';
        }

        $scope.editExercises = function(x) {
            $scope.current = angular.copy(x);
            x.editMode = true;
        };

         $scope.saveChanges = function(x) {
                x.editMode = false;
            };

        $scope.removeExercise = function(index) {
            $scope.table.splice(index, 1);
        };

        $scope.cancel = function(x) {
            x.editMode = false;
            x.name = $scope.current.name;
            x.description = $scope.current.name;
        }
    }
)

 // https://jsfiddle.net/benfosterdev/UWLFJ/
